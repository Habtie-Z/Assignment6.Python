import random
numfile =open("num.txt","w+") 

for x in range (1,100):
    numfile.write(str(random.randint(0,1000)))
    numfile.write(" ")

x= str(numfile.read())
y= x.split()
z=y.sort()

print(x)