filename = input("Enter a filename: ")   # Enter file name

infile = open(filename, "r")             # Open files for input
string = input ("Enter the string to be removed: ")              
outputfile =open("habtie.txt","w")

for line in infile.readlines():
   cleaned= line.replace(string,"")
   outputfile.write(cleaned)
   if cleaned == 'Done':
          break
print('Done')

