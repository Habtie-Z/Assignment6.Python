filename = input("Enter a filename: ").strip()     #Enter file name

infile = open(filename, "r")       # Open files for input
data = infile.read()               # Read words from the file

numOfChars = len(data)
numOfWords = len(data.split())
numOfLines = len(data.splitlines())

print(numOfChars, "characters")
print(numOfWords, "words")
print(numOfLines, "lines")