from tkinter import *     # Import all definitions from tkinter

class DisplayGraph: 
    def __init__(self):
        window = Tk()     # Create a window 
        window.title("Display a Graph")        # Set title 
        self.canvas = Canvas(window, width =300, height = 300, bg = "white")
        self.canvas.pack() 
        
        # Place canvas in the window 
        frame = Frame(window)    
        frame.pack() 
      
        self.color = StringVar()
        self.rectangle = self.canvas.create_rectangle(40, 50, 100, 250)
      
        window.mainloop()
    
DisplayGraph() # Create GUI 