from tkinter import *

class DataSet:
    '''
    This function constructos the DataSet class
    '''
    salary =open("Salary.txt","w+") 
    def __init__(self):
        window = Tk()
        window.title("DataSet")
        window.geometry('500x100')

        Label(window, text="FirstNamei").grid(row=1, column=1, sticky=W)
        Label(window, text="LastNamei").grid(row=2, column=1, sticky=W)
        Label(window, text="Rank").grid(row=3, column=1, sticky=W)
        Label(window, text="Salary").grid(row=3, column=3, sticky=W)
       

        self.firstNameiVar = StringVar()
        Entry(window, textvariable = self.firstNameiVar, justify=RIGHT).grid(row =1, column=2)

        self.lastNameiVar = StringVar()
        Entry(window, textvariable = self.lastNameiVar, justify=RIGHT).grid(row =2, column=2)

        self.rankVar = StringVar()
        Entry(window, textvariable = self.rankVar, justify=RIGHT).grid(row =3, column=2)

        self.salaryVar = StringVar()
        Entry(window, textvariable = self.salaryVar, justify=CENTER).grid(row =3, column=4)

       
        btn = Button(window, text="Display")
        btn.grid(column=2, row=4)
        window.mainloop()
     
DataSet()